library(readxl)
library(robustbase)

data <- as.data.frame(read_xlsx("RDRL.xlsx"))
colnames <- c("RDRL2","RDRL4","RDRL8","RDRL16")
for (c.lab in colnames)
{
   # png(paste0(c.lab,".png"), width=600, height=500)

   colname <- c.lab
   Rrates <- dplyr::select(data,contains(colname)) 
   RDRLsize <- as.numeric(substring(colname,5))
   
   a<-60/RDRLsize ## Maximum reinforcement (nominal) = 60/RDRLsize
   colnum <- which(names(data)==colname)

   ## Exponential fit ##
   # estimating b
   x <- data$LOR
   v <- data[,colnum]
   c <- 1:length(x)
   vmax <- max(v,na.rm=TRUE)
   pos <- which(v==vmax)
   x <- x[pos:length(x)]
   v <- v[pos:length(v)]
   c <- c[pos:length(c)]
   v23 <- 2*vmax/3
   v2 <- abs(v-v23)
   vmin <- min(v2,na.rm=TRUE)
   pos <- which(v2==vmin)
   if (pos+20>=length(x))
   {
      pos <- length(x)-20
      if(pos<1) {pos <- 1}
   }
   x <- data$LOR
   v <- data[,colnum]
   x <- x[c[pos]:length(x)]
   v <- v[c[pos]:length(v)]
   dt_tmp <- data.frame(x,v)
   equation <- paste0("v~",a,"*(exp(-x/b))")
   b = -x[1]/log(v[1]/a) 
   try(fit <-nls(equation,start=list(b=b),data=dt_tmp))
   print(fit)
   sfit <- summary(fit)
   b <- sfit$coefficients[1]
   
   ## Killeen, P. R., (1975). 
   ## On the temporal control of behavior. 
   ## Psychological review, 82(2), 89-115. 
   
   #Parameter a = Maximum reinforcement (nominal) = 60/RDRLsize
   equation <- paste0(colname,"~",a,"*(exp(-LOR/b)-exp(-LOR/c))")
   dt_tmp <- data[,c("LOR",c.lab)]
   fit <- try(robustbase::nlrob(equation,
                                start=list(b=b,c=1), trace=TRUE, data=dt_tmp))
   print(out <- summary(fit))
   b <- as.numeric(out$coeff[1])
   c <- as.numeric(out$coeff[2])
   R2 <- 1 - (deviance(fit)/sum((data$RDRL8 - mean(data$RDRL8))^2))
   
   cat("\n",c.lab,"\n")
   if(R2<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
   if(R2>=.9 & R2<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
   if(R2>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
   cat("\nR^2 = ",R2,"\n",sep="")
   cat("a=",a,", b=",b,", c=",c,"\n")

   plot(data$LOR,data[,colnum], 
        xlab="Response Rate",ylab="Reinforcers per minute", 
        ylim=c(0,a*1.1), pch=1, cex=1.5, cex.lab=1.5,
        axes=FALSE)
   axis(1)
   axis(2)
   abline(h=a, col="black", lty=4, lwd = 0.8)
   curve(a*(exp(-x/b)), 0, max(data$LOR), add=TRUE, col="black", lty=4, lwd = 0.8)
   curve(a*(1-exp(-x/c)), 0, max(data$LOR), add=TRUE, col="black", lty=4, lwd = 0.8)
   lines(data$LOR, predict(fit),col="white", lwd=7)
   lines(data$LOR, predict(fit),col="black", lwd=4)
   text(3*max(data$LOR)/4,a*1.1,
        paste0(c.lab,"s"),
        cex=2)
   text(3*max(data$LOR)/4,a*0.9,
        paste0("R²=",round(R2,3),", Killeen (1975)"),
        cex=1.4)
   cat("R max = ",max(predict(fit)))
   cat(paste0("0.364*60/",RDRLsize," = ",0.364*60/8),"\n")
   
   # dev.off()
}
