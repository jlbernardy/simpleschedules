library(readxl)
library(dplyr)
source("beak.plotbasic.R")

data <- as.data.frame(readxl::read_xlsx("RI.xlsx"))
Rrates <- dplyr::select(data,contains("RI"))
colnames <- colnames(Rrates)

# pdf("RFF_RI.pdf")
# sink("RFF_RI.txt")

for (i in colnames) 
{
  size <- as.numeric(substring(i,3))
  
  x <- data$LOR
  y <- data[,i]
  # plot(x,y, 
  #      main= paste("RFF", i, "sec"),
  #      col = "grey65", xlab="Response Rate",ylab="Reinforcers per minute")
  
  
  ## Rachlin (1978).
  ## A molar theory of reinforcement schedules 
  ## Journal of the experimental analysis of behavior, 30(3), 345-360.
  cat(paste("\nAjuste de curva de Rachlin (1978) para:", i, "\n"))
  fit.R <- try(nls(y~1/(V/60)*(LOR/200)^m,
                   start=list(V=size, m=.1), data=data))
  print(out <- summary(fit.R))
  V.R <- out$coefficients[1]
  m <- out$coefficients[2]
  R2.R <- 1-(deviance(fit.R)/sum((y-mean(y))^2))
  cat("R^2 = ",round(R2.R,4),"\n",sep="")
  if(R2.R<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
  if(R2.R>=.9 & R2.R<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
  if(R2.R>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
  # lines(data$LOR, predict(fit.R), type = "l", col = "grey30", lty = 2, lwd = 2)
  cat("\n--------------------\n")
  
  # ## Killeen (1994). 
  # ## Mathematical principles of reinforcement
  # ## Behavioral and brain sciences, 17(1), 105-135.
  
  # cat(paste("\nAjuste de curva de Killeen (1994) para:", i, "\n"))
  # fit.K2 <- try(nls(y~(1-exp(-1/LOR/a))/(1/LOR),
  #                   start = list(a=size),data=data))
  # print(out <- summary(fit.K2))
  # a <- out$coefficients[1]
  # R2.K2 <- 1-(deviance(fit.K2)/sum((y-mean(y))^2))
  # cat("R^2 = ",round(R2.R,4),"\n",sep="")
  # if(R2.K2<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
  # if(R2.K2>=.9 & R2.R<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
  # if(R2.K2>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
  # lines(data$LOR, predict(fit.K2), type = "l", col = "blue", lty = 2, lwd = 2)
  # cat("\n--------------------\n")
  
  ## Prelec, D. (1982). 
  ## Matching, maximizing, and the hyperbolic reinforcement feedback function. 
  ## Psychological Review, 89(3), 189. 
  cat(paste("\nAjuste de curva de Prelec (1982) para:", i, "\n"))
  fit.P <- try(nls(y~LOR*(1-exp(-1/((V/60)*LOR))),
                   start = list(V=size), data=data))
  print(out<-summary(fit.P))
  V.P <- out$coefficients[1]
  R2.P <- 1-(deviance(fit.P)/sum((y-mean(y))^2))
  cat("R^2 = ",round(R2.P,4),"\n",sep="")
  if(R2.P<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
  if(R2.P>=.9 & R2.P<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
  if(R2.P>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
  # lines(data$LOR, predict(fit.P), type = "l", lty=3, col = "red", lwd = 2)
  cat("\n--------------------\n")
  
  ## Killeen, P. R., (1975). 
  ## On the temporal control of behavior. 
  ## Psychological review, 82(2), 89-115. 
  
  cat(paste("\nAjuste de curva de Killeen e Sitomer (2003) para:", i, "\n"))
  fit.KS <- try(nls(y~60/V*(1-exp(-LOR/c)),
                    start = list(V=size,c=2), data=data))
  R2.KS <- 1-(deviance(fit.KS)/sum((y-mean(y))^2))
  cat("R^2 = ",round(R2.KS,4),"\n",sep="")
  if(R2.KS<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
  if(R2.KS>=.9 & R2.KS<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
  if(R2.KS>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
  print(out<-summary(fit.KS))
  V.KS <- out$coefficients[1]
  c <- out$coefficients[2]
  # lines(data$LOR, predict(fit.KS), type = "l", lty=4, col = "grey40", lwd = 2)
  cat("\n--------------------\n")
  
  
  ## Baum, W. M. (1981). 
  ## Optimization and the matching law as accounts of instrumental behavior. 
  ## Journal of the experimental analysis of behavior, 36(3), 387-403.
  
  cat(paste("\nAjuste de curva de Baum (1981) para:", i, "\n"))
  fit.B <- try(nls(y~1/(V/60+1/LOR),
                   start = list(V=size), data=data))
  R2.B <- 1-(deviance(fit.B)/sum((y-mean(y))^2))
  cat("R^2 = ",round(R2.B,4),"\n",sep="")
  if(R2.B<.9){cat("\nAjuste de curva não aceitável (R^2 < 0.9)\n")}
  if(R2.B>=.9 & R2.B<.95){cat("\nAjuste de curva aceitável e bom (R^2 >= 0.9 e R^2 < 0.95)\n")}
  if(R2.B>=.95){cat("\nAjuste de curva aceitável e excelente (R^2 >= 0.95) \n")}
  print(out<-summary(fit.B))
  V.B <- out$coefficients[1]
  # lines(data$LOR, predict(fit.B), type = "l", lty=5, col = "black", lwd = 2)
  cat("\n--------------------\n")

  
  
  cat("\n----------------------------------------\n")
  
  ## Plot ##
  # legend("bottomright",legend=c(paste0("R^2=",round(R2.R,2)," Rachlin(1978)"),
  #                               paste0("R^2=",round(R2.KS,2)," Killeen & Sitomer(2003)"),
  #                               paste0("R^2=",round(R2.P,2)," Prelec(1982)"),
  #                               paste0("R^2=",round(R2.B,2)," Baum(1981)")),
  #        lty=1:4,lwd=2, bty="n")
  
  png(paste0("FigFeedbackRI",size,"fit.png"), width=600, height=550)
  config.file = paste0("RI",size,"_c.xlsx")
  folder.in="paper_RDRLcfg"
  folder.out="paper_RDRLres"
  beak.plotbasic(config.file,
                 folder.in=folder.in,
                 folder.out=folder.out,
                 xlab="Response rate",
                 ylab="Reinforcers per minute",
                 y.line=2.5,
                 cex=1.5,
                 cex.lab=1.5,
                 normative=FALSE, hdi=FALSE,
                 title=paste0("RI ",size,"s"),
                 col="#aaaaaa",
                 smooth = TRUE)
  
  B <- 0:200
  
  V <- V.B/60
  baum <- 1/(V+1/B)
  lines(B,baum,lwd=3,lty=1)
  
  V <- V.P/60
  prelec <- B*(1-exp(-1/(V*B)))
  lines(B,prelec,lwd=3,lty=2)
  
  V <- V.R/60
  Bmax <- 200
  B <- seq(0,200,length.out=50)
  hachlin <- (1/V)*((B/Bmax)^m)
  points(B,hachlin,pch=21,col="black",bg="white",cex=0.7)
  lines(B,hachlin,lwd=1.5)
  
  B <- 0:200
  V <- 60/V.KS
  killeen <- V * (1 - exp(-B/c))
  lines(B,killeen,lwd=3,lty=4)
  
  legend ("bottomright",
          c(paste0("R²=",round(R2.B,3),", Baum (1981)"),
            paste0("R²=",round(R2.P,3),", Prelec (1982)"),
            paste0("R²=",round(R2.R,3),", Rachlin (1978)"),
            paste0("R²=",round(R2.KS,3),", Killeen (1975)")
          ),
          lty=c(1, 2, 1, 4),
          lwd=c(3,3,2,3),
          pch=c(NA,NA,21,NA),
          col=c("black","black","black","black"),
          pt.bg = c("black","black","white","black"),
          pt.cex = c(0,0,0.7,0),
          cex=1.5, box.lwd=0, bg = "transparent")
  
  dev.off()
  
  cat("\nBaum:\n")
  cat("\t V =",round(V.B,2),"\n")
  cat("\nPrelec:\n")
  cat("\t V =",round(V.P,2),"\n")
  cat("\nRachlin:\n")
  cat("\t V =",round(V.R,2),"\n")
  cat("\t m =",round(m,3),"\n")
  cat("\nKilleen:\n")
  cat("\t V =",round(V.KS,2),"\n")
  cat("\t c =",round(c,3),"\n")
  
  ## BIC e AIC ##
  cat(paste("\nComparação por BIC e AIC para:", i, "\n"))
  print(round(BIC(fit.B,fit.P,fit.R,fit.KS),0))
  print(AIC(fit.B,fit.P,fit.R,fit.KS))
}

# dev.off()
# sink()

