# beak.graphtitle.R

beak.graphtitle <- function(schedule,
                           p.resource=c("",""),
                           intervalo.tmp=c("",""),
                           LH=c(0,0),
                           amount=c("",""))
{
  txt.schedule <- schedule
  for (s in 1:sum(schedule!=""))
  {
    if (schedule[s]=="RR" | schedule[s]=="RRA")
    {
      txt.schedule[s] <- paste(txt.schedule[s]," ",round(1/p.resource[s],3), sep="")
    }
    if (schedule[s]=="RI" | schedule[s]=="RT")
    {
      txt.schedule[s] <- paste(txt.schedule[s]," ",round(intervalo.tmp[s]/p.resource[s],2),"s (T=",intervalo.tmp[s]," p=",round(p.resource[s],3),")", sep="")
    }
    if (schedule[s]=="RDRL")
    {
      txt.schedule[s] <- paste(txt.schedule[s]," ",round(intervalo.tmp[s]/p.resource[s],2),"s (d=",intervalo.tmp[s]," p=",round(p.resource[s],3),")", sep="")
    }
    if (LH[s] > 0 & (schedule[s]=="RI" | schedule[s]=="RDRL"))
    {
      txt.schedule[s] <- paste(txt.schedule[s], " LH=", LH[s], sep="")
    }
    if (nchar(amount[s]) > 0)
    {
      txt.schedule[s] <- paste(txt.schedule[s], ", A=", amount[s], sep="")
    }
  }
  main <- txt.schedule[1]
  if (sum(schedule!="") > 1)
  {
    main <- paste(main," & ",txt.schedule[2], sep="")
  }
  return(main)
}