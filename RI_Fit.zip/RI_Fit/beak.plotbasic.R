# beak.plotbasic.R

suppressMessages(library(readxl, warn.conflicts = FALSE))
suppressMessages(library(segmented, warn.conflicts = FALSE))

source("beak.readconfig.R")
source("beak.graphtitle.R")
source("eiras.friendlycolor.R")
# 
# config.file=config.file[1]
# folder.in <- "paper_RDRLcfg"
# folder.out <- "paper_RDRLres"
# normative="adj"
# smooth=FALSE
# xlim=NA
# ylim=NA

beak.plotbasic <- function (config.file,
                            folder.in=".", folder.out=".", 
                            title=TRUE,
                            col=NA, add=FALSE,
                            xlab=NA, x.line=NA,
                            ylab=NA, y.line=NA, 
                            cex=1,
                            cex.lab=1,
                            xlim=NA, ylim=NA,
                            normative="lm", smooth=FALSE,
                            hdi=TRUE,
                            schedule.pos="head", pch=21)
{
  config <- beak.readconfig(config.file, folder.in=folder.in)
  # transfere os valores
  tipo.investigacao	<- config$values[config$labels=="tipo.investigacao"]
  schedule <- LH <- amount <- p.resource <- intervalo.tmp <- c(NA,NA)
  schedule[1]	<- config$values[config$labels=="schedule1"]
  schedule[2]	<- config$values[config$labels=="schedule2"]
  LH[1]	<- as.numeric(config$values[config$labels=="LH1"])
  LH[2]	<- as.numeric(config$values[config$labels=="LH2"])
  amount[1]	<- as.numeric(config$values[config$labels=="amount1"])
  amount[2]	<- as.numeric(config$values[config$labels=="amount2"])
  p.resource[1]	<- as.numeric(config$values[config$labels=="p.resource1"])
  p.resource[2]	<- as.numeric(config$values[config$labels=="p.resource2"])
  intervalo.tmp[1]	<- as.numeric(config$values[config$labels=="intervalo.tmp1"])
  intervalo.tmp[2]	<- as.numeric(config$values[config$labels=="intervalo.tmp2"])
  repetitions	<- as.numeric(config$values[config$labels=="repetitions"])
  
  fdk.file <- paste(sub('\\..*$', '', basename(config.file)),"_fdk.xlsx",sep="")
  df_fdk <- read_excel(file.path(folder.out,fdk.file))
  # sem esquema concorrente
  if (names(df_fdk)[2]=="...2") {names(df_fdk)[2] <- ""} 

  if(tipo.investigacao=="Single")
  {
    hdi.file <- paste(sub('\\..*$', '', basename(config.file)),"_hdi.xlsx",sep="")
    df_hdi <- read_excel(file.path(folder.out,hdi.file))
  }
  
  # plot parcial do feedback
  txt.schedule <- beak.graphtitle(schedule,p.resource,intervalo.tmp,LH,amount)
  if (title==TRUE)
  {
    if (schedule.pos=="head")
    {
      main <- paste("Feedback function (",tipo.investigacao,")", sep="")
      main <- paste(main,"\n", txt.schedule, sep="")
    } else
    {
      main <- paste("Feedback function", sep="")
    }
  } else
  {
    if (title==FALSE)
    {
      main <- ""
    } else
    {
      main <- title
    }
  }
  x <- as.numeric(names(df_fdk)[3:ncol(df_fdk)])
  if (is.na(xlim[1]))  
  {
    xmin <- min(x, na.rm = TRUE)
    xmax <- max(x, na.rm = TRUE)
  } else
  {
    xmin <- xlim[1]
    xmax <- xlim[2]
  }
  if (is.na(ylim[1]))  
  {
    ymin <- min(df_fdk[,3:ncol(df_fdk)], na.rm=TRUE)
    ymax <- max(df_fdk[,3:ncol(df_fdk)], na.rm=TRUE)

    if(exists("df_hdi"))
    {
      if(tipo.investigacao=="Single")
      {
        ymin <- min(ymin,
                    as.numeric(df_hdi[1,c(3:ncol(df_hdi))]),
                    as.numeric(df_hdi[2,c(3:ncol(df_hdi))]), na.rm=TRUE)
        ymax <- max(ymax,
                    as.numeric(df_hdi[1,c(3:ncol(df_hdi))]),
                    as.numeric(df_hdi[2,c(3:ncol(df_hdi))]), na.rm=TRUE)
      }
    }
  } else
  {
    ymin <- ylim[1]
    ymax <- ylim[2]
  }
  if (!add)
  {
    plot(NA, 
         main=main,
         xlab="",
         ylab="",
         # xlim=c(190,200),
         # ylim=c(7.0,8.5),
         cex.main=cex.lab,
         cex.lab=cex.lab,
         xlim=c(xmin,xmax),
         ylim=c(ymin,ymax)
    )
    cat("################",xlab,"##################")
    if (is.na(xlab))
    {
      title(xlab="LOR (pecks per minute)",cex.lab=cex.lab, line=x.line)
    } else
    {
      title(xlab=xlab,cex.lab=cex.lab,line=x.line)
    }
    if (is.na(xlab))
    {
      title(ylab="Reinforcements per minute",cex.lab=cex.lab, line=y.line)
    }else
    {
      title(ylab=ylab,cex.lab=cex.lab,line=y.line)
    }
  }
  txt.leg <- c()
  col.leg <- c()
  lwd.leg <- c()
  lty.leg <- c()
  pch.leg <- c()
  idx <- 1
  idx.offset <- 0
  lty <- 1
  lwd <- 1

  linhas <- 1:nrow(df_fdk)
  for (r in linhas)
  {
    x <- as.numeric(names(df_fdk)[3:ncol(df_fdk)])
    if (is.na(col))
    {
      col <- idx.offset+idx
      if (col>36)
      {
        idx.offset <- idx.offset+1
        idx <- 1
        col <- idx.offset+idx
        lty <- lty+1
        if (lty>6)
        {
          lty <- 1
        }
      }
      col <- friendlycolor(col)
    }

    
    y <- as.numeric(df_fdk[r,3:ncol(df_fdk)])
    if (grepl("^[.0-9]+$", pch)) # may be converted to number
    {
      pch <- as.numeric(pch)
    }  
    # hdi, se existe
    if(exists("df_hdi"))
    {
      if(tipo.investigacao=="Single")
      {
        x.hdi <- as.numeric(names(df_hdi)[c(3:ncol(df_hdi))])
        yLL.hdi <- as.numeric(df_hdi[1,c(3:ncol(df_hdi))])
        yUL.hdi <- as.numeric(df_hdi[2,c(3:ncol(df_hdi))])
        if(hdi)
        {
          for (x.idx in 1:length(x.hdi))
          {
            lines(rep(x.hdi[x.idx],2),c(yLL.hdi[x.idx],yUL.hdi[x.idx]), col=col)
          }
        } # if hdi
      }
    }
    # pontos
    points(x,y,pch=pch,cex=cex,col=col,bg=paste(col,"88",sep=""))
    
    
    if (nchar(schedule[2])>0)
    {
      txt.linha <- paste("p[",schedule[1],"]:",round(df_fdk[r,1]*100,2),"%",sep="")
      txt.linha <- paste(txt.linha," vs ",
                         "p[",schedule[2],"]:",round(df_fdk[r,2]*100,2),"%",sep="")    
      txt.leg <- c(txt.leg, txt.linha)
      col.leg <- c(col.leg,col)
      lwd.leg <- c(lty.leg,lwd)
      lty.leg <- c(lty.leg,lty)
      pch.leg <- c(pch.leg,pch)
    }
    if(normative)
    {
      if (normative=="segmented")
      {
        rls <- lm(y~x)
        seg <- segmented::segmented(rls)
        segmented::plot.segmented(seg, add=TRUE,col=col,lty=1,lwd=1)
        # rls <- lm(y ~ poly(x,3))
        # seg <- segmented::segmented(rls)
        # segmented::plot.segmented(seg, add=TRUE,col=col,lty=1,lwd=1)
      }
      if (normative=="lm" | normative=="poly")
      {
        # only for visual adjustment
        df.xy <- data.frame(matrix(nrow=0,ncol=2))
        names(df.xy) <- c("x2","y2")
        window <- length(x)/5
        if (window<3){window<-3}
        for (i in 1:(length(x)-window+1))
        {
          df.tmp <- data.frame(matrix(nrow=0,ncol=2))
          names(df.tmp) <- c("x2","y2")
          x2 <- x[i:(i+window-1)]
          y2 <- y[i:(i+window-1)]
          if (normative=="lm")
          {
            rls <- NA
            try(
              rls <- estimatr::lm_robust(y2~x2),
              silent=TRUE
            )
            if (!is.na(rls[1]))
            {
              y2e <- rls$coefficients[1] + x2*rls$coefficients[2]
              if (smooth==FALSE)
              {
                lines(x2,y2e,col=col,lty=1,lwd=1)
              } else
              {
                df.tmp <- data.frame(x2,y2e)
              }
            }
          }
          if (normative=="poly")
          {
            model <- NA
            try(
              model <- lm(y2 ~ poly(x2,2)),
              silent=TRUE
            )
            if (!is.na(model[1]))
            {
              predicted.intervals <- predict(model,data.frame(x=x2),interval='confidence',
                                             level=0.99)
              if (smooth==FALSE)
              {
                lines(x2,predicted.intervals[,1],col=col,lty=1,lwd=1)
              } else
              {
                df.tmp <- data.frame(x2,predicted.intervals[,1])
              }
            }
          }
          names(df.tmp) <- c("x2","y2")
          df.xy <- rbind(df.xy,df.tmp)
        } # for i
        if (smooth)
        {
          ux2 <- unique(df.xy$x2)
          uy2 <- c()
          for (u in 1:length(ux2))
          {
            uy2[u] <- mean(df.xy$y2[df.xy$x2==ux2[u]],na.rm=TRUE)
          }
          lines(ux2,uy2,col=col,lty=lty,lwd=lwd)
        }
      }
    }

    # new color and symbol
    idx <- idx+3
    if (grepl("^[.0-9]+$", pch)) # may be converted to number
    {
      pch <- as.numeric(pch)
      pch <- pch+1
      if (pch>25)
      {
        pch <- 21
      }
    }
  }
  if (nchar(schedule[2])>0)
  {
    # todos os pontos juntos
    df.xy <- data.frame(matrix(nrow=0,ncol=2))
    names(df.xy) <- c("x","y")
    x <- as.numeric(names(df_fdk)[3:ncol(df_fdk)])
    for (r in 1:nrow(df_fdk))
    {
      y <- as.numeric(df_fdk[r,3:ncol(df_fdk)])
      df.tmp <- data.frame(x,y)
      names(df.tmp) <- c("x","y")
      df.xy <- rbind(df.xy,df.tmp)
    }
    
    # area mais vazia, pontos de corte
    limx <- xmin+c((xmax-xmin)*(1/3),(xmax-xmin)*(2/3))
    limy <- ymin+c((ymax-ymin)*(1/3),(ymax-ymin)*(2/3))
    # 7 8 9
    # 4 5 6
    # 1 2 3
    posleg <- c("bottomleft","bottom","bottomright",
                "left","center","right",
                "topleft","top","topright")
    df.xy$h <- NA
    df.xy$v <- NA
    df.xy$q <- NA
    df.xy$h[df.xy$x <= limx[1]] <- 1
    df.xy$h[df.xy$x >  limx[1] & df.xy$x < limx[2]] <- 2
    df.xy$h[df.xy$x >= limx[2]] <- 3
    df.xy$v[df.xy$y <= limy[1]] <- 1
    df.xy$v[df.xy$y >  limy[1] & df.xy$y < limy[2]] <- 2
    df.xy$v[df.xy$y >= limy[2]] <- 3
    # 7 8 9
    # 1,3 2,3 3,3
    # 4 5 6
    # 1,2 2,2 3,2
    # 1 2 3
    # 1,1 2,1 3,1
    df.xy$q[df.xy$h==1 & df.xy$v==3] <- 7
    df.xy$q[df.xy$h==2 & df.xy$v==3] <- 8
    df.xy$q[df.xy$h==3 & df.xy$v==3] <- 9
    df.xy$q[df.xy$h==1 & df.xy$v==2] <- 4
    df.xy$q[df.xy$h==2 & df.xy$v==2] <- 5
    df.xy$q[df.xy$h==3 & df.xy$v==2] <- 6
    df.xy$q[df.xy$h==1 & df.xy$v==1] <- 1
    df.xy$q[df.xy$h==2 & df.xy$v==1] <- 2
    df.xy$q[df.xy$h==3 & df.xy$v==1] <- 3
    df.xy$q <- factor(df.xy$q, levels=1:9)
    q <- table(df.xy$q)
    q <- as.numeric(which(q==min(q)))    
    if (length(q)>1)
    {
      q <- q[round(runif(1,1,length(q)),0)]
    }
    # legenda na posicao escolhida
    multi <- 0.7
    # if (length(txt.leg)>25)
    # {
    #   multi <- multi/(length(txt.leg)%%25)
    # }
    legend (posleg[q],
            txt.leg,
            col=col.leg,
            lwd=lwd.leg,
            lty=lty.leg,
            pch=pch.leg,
            cex=multi,
            box.lwd=0, bg="transparent")
  }

  # devolve o nome do esquema utilizado
  return(txt.schedule)
}

# png(paste0("FigFeedbackRI.png"), width=700, height=650)
# config.file = "RI5_c.xlsx"
# folder.in="paper_RDRLcfg"
# folder.out="paper_RDRLres"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                xlab="Response rate",
#                ylab="Reinforcers per minute",
#                ylim=c(0,14),
#                y.line=2.5,
#                cex.lab=1.8,
#                normative=FALSE,
#                title="RI feedback functions",
#                col="#000000",
#                smooth = TRUE)
# config.file = "RI15_c.xlsx"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                normative=FALSE,
#                col="#444444",
#                smooth = TRUE,
#                add=TRUE)
# config.file = "RI60_c.xlsx"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                normative=FALSE,
#                smooth = TRUE,
#                col="#999999",
#                add=TRUE)
# text(100,1.8,"5.05s (T=0.197, p=0.039)",cex=1.3)
# text(100,5,"15.15s (T=0.591, p=0.039)",cex=1.3)
# text(100,12.2,"59.92s (T=1, p=0.017)",cex=1.3)
# dev.off()
# 
# png(paste0("FigFeedbackRDRL.png"), width=700, height=650)
# config.file = "RDRL2_c.xlsx"
# folder.in="paper_RDRLcfg"
# folder.out="paper_RDRLres"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                xlab="Response rate",
#                ylab="Reinforcers per minute",
#                ylim=c(0,14),
#                y.line=2.5,
#                cex.lab=1.8,
#                normative=FALSE,
#                title="RDRL feedback functions",
#                col="#000000",
#                smooth = TRUE)
# config.file = "RDRL4_c.xlsx"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                normative=FALSE,
#                col="#444444",
#                smooth = TRUE,
#                add=TRUE)
# config.file = "RDRL8_c.xlsx"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                normative=FALSE,
#                smooth = TRUE,
#                col="#999999",
#                add=TRUE)
# config.file = "RDRL16_c.xlsx"
# beak.plotbasic(config.file,
#                folder.in=folder.in,
#                folder.out=folder.out,
#                normative=FALSE,
#                smooth = TRUE,
#                col="#999999",
#                add=TRUE)
# text(150,12.3,"2s (d=0.5, p=0.25)",cex=1.3)
# text(140,4.8,"4s (d=1, p=0.25)",cex=1.3)
# text(120,1.3,"8s (d=2, p=0.25)",cex=1.3)
# text(70,0.7,"16s (d=4, p=0.25)",cex=1.3)
# dev.off()
