# eiras.beak.readconfig.R
# 
# config.file <- "teste.xlsx"
# folder.in <- "config_teste"

beak.readconfig <- function(config.file, folder.in=".")
{
  config.file.path <- file.path(folder.in,config.file)
  config <- readxl::read_excel(config.file.path)
  names(config) <- c("Beak", "Variavel1", "Variavel2", "Alternativas")
  config <- config[!is.na(config$Beak),]
  
  # em quantas partes divido 1 segundo
  subseconds <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Subseconds"])
  
  # tipo de investigacao
  tipo.investigacao <- config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Investigation"]
  # tipo de processamento
  processing <- config$Variavel1[!is.na(config$Variavel1) & 
                                          config$Beak=="Processing"]
  if(length(processing)==0) {processing <- "R"}
  p.steps <- 0
  p.ini <- 0
  p.end <- 0
  if (tipo.investigacao=="Concurrent")
  {
    p.steps <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.steps"])
    p.ini <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.ini"])
    p.end <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.end"])
    
  }
  
  # tipo de exploracao
  # - c("Adaptative", "Range")
  exploration <- config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Exploration"]
 
  # LOR inicial e range (se aplicavel)
  iniLOR <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="iniLOR"])  
  endLOR <- NA
  if (exploration=="Range")
  {
    endLOR <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="endLOR"])  
  }
  
  # numero de repeticoes
  repetitions <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Repetitions"])
  if (repetitions<10)
  {
    repetitions <- 10
    # cat("Warning: at least 10 repetitions are necessary\n")
  }
  
  # numero de sessoes
  steps <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Steps"])
  # duracao de cada sessao
  session <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Session"])
  
  # tipos de esquema
  # - c("RR", "RI", "RDRL", "RT", "RRA")
  schedule <- c("","")
  intervalo.tmp <- c(NA,NA)    
  p.resource <- c(NA,NA)    
  schedule[1] <- config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Schedule"]
  if (tipo.investigacao=="Concurrent")
  {
    schedule[2] <- config$Variavel2[!is.na(config$Variavel2) & 
                         config$Beak=="Schedule"]
  } else
  {
    schedule[2] <- ""
  }
  LH <- c(NA,NA)
  LH[1] <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="LH"])
  if (tipo.investigacao=="Concurrent")
  {
    LH[2] <- as.numeric(
      config$Variavel2[!is.na(config$Variavel2) & 
                         config$Beak=="LH"])
  }
  
  amount <- c(NA,NA)
  amount[1] <- as.numeric(
    config$Variavel1[!is.na(config$Variavel1) & 
                       config$Beak=="Amount"])
  if (tipo.investigacao=="Concurrent")
  {
    amount[2] <- as.numeric(
      config$Variavel2[!is.na(config$Variavel2) & 
                         config$Beak=="Amount"])
  }

  # tipo de schedule para simular
  if (schedule[1]=="RR" | schedule[1]=="RRA")
  {
    # probabilidade de obter recurso a cada bicada
    p.resource[1] <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.RR"]
    )
  }
  if (schedule[1]=="RI" | schedule[1]=="RT")
  {
    intervalo.tmp[1] <-  as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="T"]
    )  
    p.resource[1] <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.RI"])
  }
  if (schedule[1]=="RDRL")
  {
    intervalo.tmp[1] <-  as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="d"])  
    p.resource[1] <- as.numeric(
      config$Variavel1[!is.na(config$Variavel1) & 
                         config$Beak=="p.RDRL"])
  }
  # pode existir um segundo schedule
  if (tipo.investigacao=="Concurrent")
  {
    if (schedule[2]=="RR" | schedule[2]=="RRA")
    {
      # probabilidade de obter recurso a cada bicada
      p.resource[2] <- as.numeric(
        config$Variavel2[!is.na(config$Variavel2) & 
                           config$Beak=="p.RR"])
    }
    if (schedule[2]=="RI" | schedule[2]=="RT")
    {
      intervalo.tmp[2] <-  as.numeric(
        config$Variavel2[!is.na(config$Variavel2) & 
                           config$Beak=="T"])  
      p.resource[2] <- as.numeric(
        config$Variavel2[!is.na(config$Variavel2) & 
                           config$Beak=="p.RI"])
    }
    if (schedule[2]=="RDRL")
    {
      intervalo.tmp[2] <-  as.numeric(
        config$Variavel2[!is.na(config$Variavel2) & 
                           config$Beak=="d"])  
      p.resource[2] <- as.numeric(
        config$Variavel2[!is.na(config$Variavel2) & 
                           config$Beak=="p.RDRL"])
    }
  }
  
  labels <-     c(
    "tipo.investigacao",
    "processing",
    "p.steps",
    "p.ini",
    "p.end",
    "repetitions",
    "steps",
    "session",
    "subseconds",
    "exploration",
    "iniLOR",
    "endLOR",
    "schedule1","schedule2",
    "LH1","LH2",
    "amount1","amount2",
    "p.resource1","p.resource2",
    "intervalo.tmp1","intervalo.tmp2"
  )
  values <-     c(
    tipo.investigacao,
    processing,
    p.steps,
    p.ini,
    p.end,
    repetitions,
    steps,
    session,
    subseconds,
    exploration,
    iniLOR,
    endLOR,
    schedule,
    LH,
    amount,
    p.resource,
    intervalo.tmp
  )
  
  retorno <- data.frame(labels,values)
  retorno[,] <- lapply(retorno[,],as.character)
  
  return(retorno)
}

